CleanYourTV V13

本版依照最新需求更新設定選單、桌面隱藏管理、桌布聚焦效果、資料夾 4 欄 TV 圖示及固定列黑色底板間距。

Android 專案：cleanyourtv-main/launcher
建置方式：在 launcher 目錄執行 ./gradlew assembleDebug
